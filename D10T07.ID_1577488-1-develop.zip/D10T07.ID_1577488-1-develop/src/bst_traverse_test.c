#include <stdio.h>
#include <stdlib.h>
#include "bst.h"

#define SUCCESS 0
#define FAIL 1

int compare(int a, int b)
{
    return a - b;
}

void print_item(int item)
{
    printf("%d ", item);
}

void destroy_tree(t_btree *root)
{
    if (root == NULL) {
        return;
    }
    destroy_tree(root->left);
    destroy_tree(root->right);
    free(root);
}

// Создаём тестовое дерево: [10, 5, 15, 3, 7, 12, 18]
t_btree *create_test_tree(void)
{
    t_btree *root = bstree_create_node(10);
    if (root == NULL) {
        return NULL;
    }
    bstree_insert(root, 5, compare);
    bstree_insert(root, 15, compare);
    bstree_insert(root, 3, compare);
    bstree_insert(root, 7, compare);
    bstree_insert(root, 12, compare);
    bstree_insert(root, 18, compare);
    return root;
}

int test_infix(void)
{
    t_btree *root = create_test_tree();
    if (root == NULL) {
        return FAIL;
    }
    
    printf("  Infix (expected: 3 5 7 10 12 15 18): ");
    bstree_apply_infix(root, print_item);
    printf("\n");
    
    destroy_tree(root);
    return SUCCESS;
}

int test_prefix(void)
{
    t_btree *root = create_test_tree();
    if (root == NULL) {
        return FAIL;
    }
    
    printf("  Prefix (expected: 10 5 3 7 15 12 18): ");
    bstree_apply_prefix(root, print_item);
    printf("\n");
    
    destroy_tree(root);
    return SUCCESS;
}

int test_postfix(void)
{
    t_btree *root = create_test_tree();
    if (root == NULL) {
        return FAIL;
    }
    
    printf("  Postfix (expected: 3 7 5 12 18 15 10): ");
    bstree_apply_postfix(root, print_item);
    printf("\n");
    
    destroy_tree(root);
    return SUCCESS;
}

int main(void)
{
    int result = SUCCESS;
    
    printf("Testing BST traversing:\n");
    
    if (test_infix() == SUCCESS) {
        printf("    SUCCESS\n");
    } else {
        printf("    FAIL\n");
        result = FAIL;
    }
    
    if (test_prefix() == SUCCESS) {
        printf("    SUCCESS\n");
    } else {
        printf("    FAIL\n");
        result = FAIL;
    }
    
    if (test_postfix() == SUCCESS) {
        printf("    SUCCESS\n");
    } else {
        printf("    FAIL\n");
        result = FAIL;
    }
    
    return result;
}
