#include <stdlib.h>
#include "stack.h"

struct stack *init(void)
{
    struct stack *s = (struct stack *)malloc(sizeof(struct stack));
    if (s == NULL) {
        return NULL;
    }
    s->top = NULL;
    return s;
}

void push(struct stack *s, int value)
{
    if (s == NULL) {
        return;
    }

    struct stack_node *new_node = (struct stack_node *)malloc(sizeof(struct stack_node));
    if (new_node == NULL) {
        return;
    }

    new_node->value = value;
    new_node->next = s->top;
    s->top = new_node;
}

int pop(struct stack *s)
{
    if (s == NULL || s->top == NULL) {
        return -1;  // Стек пуст
    }

    struct stack_node *temp = s->top;
    int value = temp->value;
    s->top = s->top->next;
    free(temp);

    return value;
}

void destroy(struct stack *s)
{
    if (s == NULL) {
        return;
    }

    struct stack_node *current = s->top;
    struct stack_node *next_node;

    while (current != NULL) {
        next_node = current->next;
        free(current);
        current = next_node;
    }

    free(s);
}
