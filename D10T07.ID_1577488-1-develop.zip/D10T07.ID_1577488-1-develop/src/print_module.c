#include <stdio.h>
#include <time.h>
#include "print_module.h"

char print_char(char ch) 
{
    return putchar(ch);
}

void print_log(char (*print) (char), char* message)
{
    time_t rawtime;
    struct tm *timeinfo;
    
    time(&rawtime);
    timeinfo = localtime(&rawtime);
    
    // [LOG]
    print('[');
    print('L');
    print('O');
    print('G');
    print(']');
    print(' ');
    
    // HH:MM:SS
    char time_str[9];
    strftime(time_str, sizeof(time_str), "%H:%M:%S", timeinfo);
    
    for (int i = 0; time_str[i] != '\0'; i++) {
        print(time_str[i]);
    }
    
    print(' ');
    
    // message
    for (int i = 0; message[i] != '\0'; i++) {
        print(message[i]);
    }
}
