#include <stdio.h>
#include <stdlib.h>
#include "bst.h"

#define SUCCESS 0
#define FAIL 1

// Объявление функции destroy_tree
void destroy_tree(t_btree *root);

int test_create_node(void)
{
    t_btree *node = bstree_create_node(42);
    if (node == NULL) {
        return FAIL;
    }
    
    if (node->item != 42) {
        destroy_tree(node);
        return FAIL;
    }
    
    if (node->left != NULL || node->right != NULL) {
        destroy_tree(node);
        return FAIL;
    }
    
    destroy_tree(node);
    return SUCCESS;
}

int test_create_node_zero(void)
{
    t_btree *node = bstree_create_node(0);
    if (node == NULL) {
        return FAIL;
    }
    
    if (node->item != 0) {
        destroy_tree(node);
        return FAIL;
    }
    
    destroy_tree(node);
    return SUCCESS;
}

void destroy_tree(t_btree *root)
{
    if (root == NULL) {
        return;
    }
    destroy_tree(root->left);
    destroy_tree(root->right);
    free(root);
}

int main(void)
{
    int result = SUCCESS;
    
    printf("Testing create node with 42...\n");
    if (test_create_node() == SUCCESS) {
        printf("  SUCCESS\n");
    } else {
        printf("  FAIL\n");
        result = FAIL;
    }
    
    printf("Testing create node with 0...\n");
    if (test_create_node_zero() == SUCCESS) {
        printf("  SUCCESS\n");
    } else {
        printf("  FAIL\n");
        result = FAIL;
    }
    
    return result;
}
