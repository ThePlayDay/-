#include <stdio.h>
#include "list.h"

#define SUCCESS 0
#define FAIL 1

int test_add_door(void)
{
    struct door door1 = {1, 0};
    struct door door2 = {2, 0};
    struct door door3 = {3, 0};

    struct node *root = init(door1);
    if (root == NULL) {
        return FAIL;
    }

    struct node *second = add_door(root, door2);
    if (second == NULL) {
        destroy(root);
        return FAIL;
    }

    struct node *third = add_door(second, door3);
    if (third == NULL) {
        destroy(root);
        return FAIL;
    }

    if (root->door.id != 1 || root->next->door.id != 2 || root->next->next->door.id != 3) {
        destroy(root);
        return FAIL;
    }

    if (root->next->next->next != NULL) {
        destroy(root);
        return FAIL;
    }

    destroy(root);
    return SUCCESS;
}

int test_remove_door(void)
{
    struct door door1 = {1, 0};
    struct door door2 = {2, 0};
    struct door door3 = {3, 0};

    struct node *root = init(door1);
    if (root == NULL) {
        return FAIL;
    }

    struct node *second = add_door(root, door2);
    if (second == NULL) {
        destroy(root);
        return FAIL;
    }

    add_door(second, door3);

    root = remove_door(second, root);

    if (root->door.id != 1) {
        destroy(root);
        return FAIL;
    }

    if (root->next->door.id != 3) {
        destroy(root);
        return FAIL;
    }

    if (root->next->next != NULL) {
        destroy(root);
        return FAIL;
    }

    destroy(root);
    return SUCCESS;
}

int main(void)
{
    int result = SUCCESS;

    printf("Testing add_door...\n");
    if (test_add_door() == SUCCESS) {
        printf("  SUCCESS\n");
    } else {
        printf("  FAIL\n");
        result = FAIL;
    }

    printf("Testing remove_door...\n");
    if (test_remove_door() == SUCCESS) {
        printf("  SUCCESS\n");
    } else {
        printf("  FAIL\n");
        result = FAIL;
    }

    return result;
}