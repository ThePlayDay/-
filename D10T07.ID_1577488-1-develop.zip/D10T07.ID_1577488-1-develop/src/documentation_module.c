#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "documentation_module.h"

int validate(char* data)
{
    int validation_result = !strcmp(data, Available_document);
    return validation_result;
}

int* check_available_documentation_module(int (*validate) (char*), int document_count, ...)
{
    if (validate == NULL || document_count <= 0) {
        return NULL;
    }

    int *availability = (int*)malloc(document_count * sizeof(int));
    if (availability == NULL) {
        return NULL;
    }

    va_list args;
    va_start(args, document_count);

    for (int i = 0; i < document_count; i++) {
        char *doc_name = va_arg(args, char*);
        availability[i] = validate(doc_name);
    }

    va_end(args);
    return availability;
}
