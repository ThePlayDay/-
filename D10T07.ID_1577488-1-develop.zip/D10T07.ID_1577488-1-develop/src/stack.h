#ifndef STACK_H
#define STACK_H

// Структура узла стека
struct stack_node {
    int value;
    struct stack_node *next;
};

// Структура стека (хранит указатель на вершину)
struct stack {
    struct stack_node *top;
};

// Инициализация пустого стека
struct stack *init(void);

// Добавление элемента на вершину стека
void push(struct stack *s, int value);

// Удаление и возврат элемента с вершины стека
int pop(struct stack *s);

// Освобождение памяти стека
void destroy(struct stack *s);

#endif
