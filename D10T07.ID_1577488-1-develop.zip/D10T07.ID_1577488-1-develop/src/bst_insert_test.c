#include <stdio.h>
#include <stdlib.h>
#include "bst.h"

#define SUCCESS 0
#define FAIL 1

int compare(int a, int b)
{
    return a - b;
}

void destroy_tree(t_btree *root)
{
    if (root == NULL) {
        return;
    }
    destroy_tree(root->left);
    destroy_tree(root->right);
    free(root);
}

void print_tree_infix(t_btree *root)
{
    if (root == NULL) {
        return;
    }
    print_tree_infix(root->left);
    printf("%d ", root->item);
    print_tree_infix(root->right);
}

int test_insert(void)
{
    t_btree *root = bstree_create_node(10);
    if (root == NULL) {
        return FAIL;
    }
    
    bstree_insert(root, 5, compare);
    bstree_insert(root, 15, compare);
    bstree_insert(root, 3, compare);
    bstree_insert(root, 7, compare);
    bstree_insert(root, 12, compare);
    bstree_insert(root, 18, compare);
    
    // Проверяем структуру дерева
    if (root->left->item != 5 || root->right->item != 15) {
        destroy_tree(root);
        return FAIL;
    }
    
    if (root->left->left->item != 3 || root->left->right->item != 7) {
        destroy_tree(root);
        return FAIL;
    }
    
    if (root->right->left->item != 12 || root->right->right->item != 18) {
        destroy_tree(root);
        return FAIL;
    }
    
    destroy_tree(root);
    return SUCCESS;
}

int test_insert_duplicate(void)
{
    t_btree *root = bstree_create_node(10);
    if (root == NULL) {
        return FAIL;
    }
    
    bstree_insert(root, 5, compare);
    bstree_insert(root, 5, compare);  // Вставка дубликата
    
    // Дубликат должен пойти в правое поддерево
    if (root->left->right == NULL) {
        destroy_tree(root);
        return FAIL;
    }
    
    destroy_tree(root);
    return SUCCESS;
}

int main(void)
{
    int result = SUCCESS;
    
    printf("Testing BST insert...\n");
    if (test_insert() == SUCCESS) {
        printf("  SUCCESS\n");
    } else {
        printf("  FAIL\n");
        result = FAIL;
    }
    
    printf("Testing BST insert duplicate...\n");
    if (test_insert_duplicate() == SUCCESS) {
        printf("  SUCCESS\n");
    } else {
        printf("  FAIL\n");
        result = FAIL;
    }
    
    return result;
}
