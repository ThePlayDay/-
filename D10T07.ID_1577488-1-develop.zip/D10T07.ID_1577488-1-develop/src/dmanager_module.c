#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "door_struct.h"

#define DOORS_COUNT 15
#define MAX_ID_SEED 10000

/*
 * Прототипы функций (объявления)
 * Это необходимо для соблюдения принципа "разработка сверху вниз"
 */

/**
 * @brief Устанавливает статус "закрыто" для всех дверей
 * @param doors - указатель на массив дверей
 * @param count - количество дверей в массиве
 */
void close_all_doors(struct door *doors, int count);

/**
 * @brief Сортирует массив дверей по возрастанию id (пузырьковая сортировка)
 * @param doors - указатель на массив дверей
 * @param count - количество дверей в массиве
 */
void sort_doors_by_id(struct door *doors, int count);

/**
 * @brief Выводит массив дверей на экран в формате "id, status"
 * @param doors - указатель на массив дверей
 * @param count - количество дверей в массиве
 */
void print_doors(const struct door *doors, int count);

/**
 * @brief Инициализирует массив дверей (функция дана, НЕ ИЗМЕНЯТЬ!)
 * @param doors - указатель на массив дверей
 */
void initialize_doors(struct door *doors);

/**
 * @brief Точка входа в программу
 * @return 0 - успешное завершение
 */
int main(void);

/* ============================================================ */
/* РЕАЛИЗАЦИЯ ФУНКЦИЙ                                           */
/* ============================================================ */

int main(void)
{
    struct door doors[DOORS_COUNT];

    initialize_doors(doors);
    close_all_doors(doors, DOORS_COUNT);
    sort_doors_by_id(doors, DOORS_COUNT);
    print_doors(doors, DOORS_COUNT);

    return 0;
}

void close_all_doors(struct door *doors, int count)
{
    /* Предварительная проверка аргументов (разрешённое исключение) */
    if (doors == NULL) {
        return;
    }

    /* Единственный цикл, одна точка выхода */
    for (int i = 0; i < count; i++) {
        doors[i].status = 0;
    }
}

void sort_doors_by_id(struct door *doors, int count)
{
    /* Предварительная проверка аргументов (разрешённое исключение) */
    if (doors == NULL) {
        return;
    }

    /* Пузырьковая сортировка с единственной точкой выхода */
    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - i - 1; j++) {
            if (doors[j].id > doors[j + 1].id) {
                struct door temp = doors[j];
                doors[j] = doors[j + 1];
                doors[j + 1] = temp;
            }
        }
    }
}

void print_doors(const struct door *doors, int count)
{
    /* Предварительная проверка аргументов (разрешённое исключение) */
    if (doors == NULL) {
        return;
    }

    for (int i = 0; i < count; i++) {
        printf("%d, %d\n", doors[i].id, doors[i].status);
    }
}

/* ============================================================ */
/* ФУНКЦИЯ ИНИЦИАЛИЗАЦИИ (ДАНО, НЕ ИЗМЕНЯТЬ!)                   */
/* ============================================================ */

void initialize_doors(struct door *doors)
{
    srand(time(0));

    int seed = rand() % MAX_ID_SEED;
    for (int i = 0; i < DOORS_COUNT; i++) {
        doors[i].id = (i + seed) % DOORS_COUNT;
        doors[i].status = rand() % 2;
    }
}