#include <stdio.h>
#include <stdlib.h>
#include "documentation_module.h"

int main(void)
{
    char *documents[] = { "Linked lists", "Queues", "Maps", "Binary Trees" };
    int documents_count = 4;
    
    int *availability = check_available_documentation_module(validate, documents_count, 
                                                              documents[0], documents[1], 
                                                              documents[2], documents[3]);
    
    if (availability == NULL) {
        printf("Error: failed to check documentation availability\n");
        return 1;
    }
    
    for (int i = 0; i < documents_count; i++) {
        printf("[%15s : %s]\n", documents[i], availability[i] ? "available" : "unavailable");
    }
    
    free(availability);
    return 0;
}
