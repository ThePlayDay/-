#include <stdio.h>
#include "stack.h"

#define SUCCESS 0
#define FAIL 1

// Тест для push
int test_push(void)
{
    struct stack *s = init();
    if (s == NULL) {
        return FAIL;
    }

    push(s, 10);
    push(s, 20);
    push(s, 30);

    if (s->top == NULL || s->top->value != 30) {
        destroy(s);
        return FAIL;
    }

    if (s->top->next->value != 20) {
        destroy(s);
        return FAIL;
    }

    if (s->top->next->next->value != 10) {
        destroy(s);
        return FAIL;
    }

    if (s->top->next->next->next != NULL) {
        destroy(s);
        return FAIL;
    }

    destroy(s);
    return SUCCESS;
}

// Тест для pop
int test_pop(void)
{
    struct stack *s = init();
    if (s == NULL) {
        return FAIL;
    }

    push(s, 100);
    push(s, 200);
    push(s, 300);

    int val1 = pop(s);
    int val2 = pop(s);
    int val3 = pop(s);

    if (val1 != 300 || val2 != 200 || val3 != 100) {
        destroy(s);
        return FAIL;
    }

    destroy(s);
    return SUCCESS;
}

// Тест для pop на пустом стеке
int test_pop_empty(void)
{
    struct stack *s = init();
    if (s == NULL) {
        return FAIL;
    }

    int val = pop(s);

    if (val != -1) {
        destroy(s);
        return FAIL;
    }

    destroy(s);
    return SUCCESS;
}

int main(void)
{
    int result = SUCCESS;

    printf("Testing push...\n");
    if (test_push() == SUCCESS) {
        printf("  SUCCESS\n");
    } else {
        printf("  FAIL\n");
        result = FAIL;
    }

    printf("Testing pop...\n");
    if (test_pop() == SUCCESS) {
        printf("  SUCCESS\n");
    } else {
        printf("  FAIL\n");
        result = FAIL;
    }

    printf("Testing pop on empty stack...\n");
    if (test_pop_empty() == SUCCESS) {
        printf("  SUCCESS\n");
    } else {
        printf("  FAIL\n");
        result = FAIL;
    }

    return result;
}
