#include <stdio.h>

int main(void) {
    double x, y;
    if (scanf("%lf %lf", &x, &y) != 2) {
        printf("n/a");
        return 0;
    }

    if (x * x + y * y < 25.0) {
        printf("GOTCHA");
    } else {
        printf("MISS");
    }

    return 0;
}