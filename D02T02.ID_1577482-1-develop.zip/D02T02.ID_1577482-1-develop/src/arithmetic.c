#include <stdio.h>

int main(void) {
    int a, b;
    if (scanf("%d %d", &a, &b) != 2) {
        printf("n/a");
        return 0;
    }

    int sum = a + b;
    int diff = a - b;
    int prod = a * b;

    if (b == 0) {
        printf("%d %d %d n/a", sum, diff, prod);
    } else {
        int quot = a / b;
        printf("%d %d %d %d", sum, diff, prod, quot);
    }

    return 0;
}