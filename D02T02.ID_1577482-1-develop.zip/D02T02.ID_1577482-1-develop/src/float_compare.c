#include <math.h>
#include <stdio.h>

double fun();

int main(void) {
    double res = fun();

    double epsilon = 1e-6;
    if (fabs(res) < epsilon) {
        printf("OK!");
    }

    return 0;
}

double fun() { return (1.0 / 13) * pow(((2 - 1.0) / (2 + 1.0)), 20); }