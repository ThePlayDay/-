#include <math.h>
#include <stdio.h>

int main(void) {
    double x;
    if (scanf("%lf", &x) != 1) {
        printf("n/a");
        return 0;
    }

    double x2 = x * x;
    double x4 = x2 * x2;
    double x_cuberoot = cbrt(x);
    double term1 = 7e-3 * x4;
    double term2_num = (22.8 * x_cuberoot - 1000.0) * x + 3.0;
    double term2_den = x2 / 2.0;
    double term2 = term2_num / term2_den;
    double term3 = x * pow(10.0 + x, 2.0 / x);
    double y = term1 + term2 - term3 - 1.01;

    printf("%.1f", y);
    return 0;
}