#include <stdio.h>

int max(int a, int b) {
    int result = a;
    if (b > a) {
        result = b;
    }
    return result;
}

int main(void) {
    int a, b;
    if (scanf("%d %d", &a, &b) != 2) {
        printf("n/a");
        return 0;
    }

    printf("%d", max(a, b));
    return 0;
}