# Instructions for running tests

In addition to testing for correct output data, the autotest system will
check your program and its source code for the following points:

* **Style tests.** The _C_ and _C++_ code should follow _Google C++ Style Guide_. To check how much the beauty of your code matches
  for example, you can test your code using the _clang-format_ utility.
  The ```materials/linters``` folder contains the ```.clang-format``` file, which contains
  the necessary settings for the style test. This configuration file extends its action to all files that lie with it in the directory
  or in the directories below. So in order for these settings to apply to your source code files,
  copy ```.clang-format``` to the ```src``` folder. \
  \
  To run the style check, run the following command: \
  ```clang-format -n src/sourcefile_name.c``` 

  Required version of clang-format: \
  **Mac** 18.1.8 \
  **Linux** 18.1.8