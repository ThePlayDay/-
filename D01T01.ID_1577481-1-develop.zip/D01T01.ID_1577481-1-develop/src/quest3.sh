bash ai_door_management_module.sh
find .. -name "door_management_files"
mv ../door_management_files .
mkdir door_management_files
touch door_management_files/door_configuration door_management_files/door_map door_management_files/door_logs
cat ai_door_management_module.sh
rm door_management_files/door_configuration door_management_files/door_map door_management_files/door_logs
mkdir door_management_files/door_configuration door_management_files/door_map door_management_files/door_logs
mv door_management_fi/*.conf door_management_files/door_configuration/
mv door_management_fi/door_map_1.1 door_management_files/door_map/
mv door_management_fi/*.log door_management_files/door_logs/
rmdir door_management_fi
find .. -name "*.conf" -o -name "door_map_1.1" -o -name "*.log"
find .. -name "*.conf" -o -name "door_map_1.1" -o -name "*.log"
find .. -name "*.conf" -o -name "door_map_1.1" -o -name "*.log"
find .. -name "*.conf" -o -name "door_map_1.1" -o -name "*.log"
